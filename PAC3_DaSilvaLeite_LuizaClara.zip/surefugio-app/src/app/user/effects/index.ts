import { UserEffects } from "./user.effects";

export const EffectsArray: any[] = [UserEffects];