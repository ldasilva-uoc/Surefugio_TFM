import { ProtectorasEffects } from "./protectora.effects";


export const EffectsArray: any[] = [ProtectorasEffects];