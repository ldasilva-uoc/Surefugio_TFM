import { AnimalesEffects } from "./animal.effects";

export const EffectsArray: any[] = [AnimalesEffects];