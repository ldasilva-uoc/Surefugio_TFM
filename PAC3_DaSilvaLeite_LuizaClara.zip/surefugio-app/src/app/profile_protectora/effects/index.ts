import { ProfileProtectoraEffects } from "./protectora.profile.effects";

export const EffectsArray: any[] = [ProfileProtectoraEffects]