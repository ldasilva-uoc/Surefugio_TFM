export class Credencial{
    public email:string;
    public password:boolean;
}