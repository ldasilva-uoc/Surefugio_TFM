<?php $__env->startComponent('mail::message'); ?>
# ¡Quiero acoger!

<?php $__env->slot('header'); ?>
<?php $__env->startComponent('mail::header', ['url' => '']); ?>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php $__env->endSlot(); ?>



El usuario quiere acoger a.
The body of your message.


Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\Programacion\xampp3\htdocs\Surefugio_TFM\Surefugio_TFM\surefugio_api\resources\views/emails/quiero-adoptar.blade.php ENDPATH**/ ?>