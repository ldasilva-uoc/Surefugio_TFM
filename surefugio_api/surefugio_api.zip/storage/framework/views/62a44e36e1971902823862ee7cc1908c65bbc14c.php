[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH D:\Programacion\xampp3\htdocs\Surefugio_TFM\Surefugio_TFM\surefugio_api\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>