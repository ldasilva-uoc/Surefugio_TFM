<!DOCTYPE html>
<html>
    <head>
        <title>Un usuario quiere adoptar</title>
    </head>
    <body>
        <p>Mensaje</p>
    </body>

</html><?php /**PATH D:\Programacion\xampp3\htdocs\Surefugio_TFM\Surefugio_TFM\surefugio_api\resources\views/emails/quiero-adoptar.blade.php ENDPATH**/ ?>