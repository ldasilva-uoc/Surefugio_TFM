<tr>
<td class="header">
<a href="<?php echo e($url); ?>" style="display: inline-block;">
<?php if(trim($slot) === 'Laravel'): ?>
<img src="https://laravel.com/img/notification-logo.png" class="logo" alt="Laravel Logo">
<?php else: ?>
<?php echo e($slot); ?>

<?php endif; ?>
</a>
</td>
</tr>
<?php /**PATH D:\Programacion\xampp3\htdocs\Surefugio_TFM\Surefugio_TFM\surefugio_api\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>