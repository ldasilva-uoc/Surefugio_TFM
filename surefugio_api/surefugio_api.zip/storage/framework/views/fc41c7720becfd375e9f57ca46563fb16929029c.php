<?php echo e($slot); ?>

<?php /**PATH D:\Programacion\xampp3\htdocs\Surefugio_TFM\Surefugio_TFM\surefugio_api\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>