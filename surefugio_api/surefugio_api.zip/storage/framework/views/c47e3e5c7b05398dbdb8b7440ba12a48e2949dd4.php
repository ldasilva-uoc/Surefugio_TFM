<?php $__env->startComponent('mail::message'); ?>
# ¡Quiero Adoptar!

<?php $__env->slot('header'); ?>
<?php $__env->startComponent('mail::header', ['url' => '']); ?>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php $__env->endSlot(); ?>



El usuario <b><?php echo e($particular->nombre); ?></b> quiere adoptar a <b><?php echo e($animal->nombre); ?></b>. <p>Contacta con <?php echo e($particular->nombre); ?>:</p>
<ul>
    <li>Email: <?php echo e($userParticular->email); ?></li>
    <li>Telefono: <?php echo e($particular->telefono); ?></li>
</ul>
<br>
Muchas gracias!,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH D:\Programacion\xampp3\htdocs\Surefugio_TFM\Surefugio_TFM\surefugio_api\resources\views/emails/animal-adoptar.blade.php ENDPATH**/ ?>